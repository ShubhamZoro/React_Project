import Styles from "./AppName.module.css";
function AppName() {
  return <h1 className={Styles.todoHeading}>TODO APP</h1>;
}

export default AppName;
