import style from "./Dispaly.module.css";
function Dispaly() {
  return <input className={style.display} type="text"></input>;
}

export default Dispaly;
