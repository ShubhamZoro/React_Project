function AppDescription() {
  return <p className="lead">This will tell you time about India</p>;
}

export default AppDescription;
